//
//  ViewController.swift
//  Homework8
//
//  Created by Eddy Lardet on 4/20/16.
//  Copyright © 2016 Eddy Lardet. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate{
    
    @IBOutlet weak var tabelView: UITableView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    var concerts = [Concert]()
    
    var temp = TableViewCell()
    
    var filteredTableData = [Concert]()
    
    var resultSearchController = UISearchController()
    
    var strDate: String = ""
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Use the edit button item provided by the table view controller.
        navigationItem.leftBarButtonItem = editButtonItem()
        
        // Load any saved meals, otherwise load sample data.
        if let savedConcerts = loadConcerts() {
            concerts += savedConcerts
        } else {
            // Load the sample data.
            loadSampleMeals()
        }
        
        self.filterConcerts()
        
        self.searchBar.delegate = self
        
        datePicker.addTarget(self, action: #selector(ViewController.datePickerChanged(_:)), forControlEvents: UIControlEvents.ValueChanged)
        
    }
    
    func filterConcerts() {
        let dateFormatter = NSDateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let strDate = dateFormatter.stringFromDate(datePicker.date)
        self.strDate = strDate
        filteredTableData.removeAll(keepCapacity: false)
        
        for object:Concert in concerts {
            if object.date == strDate {
                if searchBar.text! != "" {
                    if object.name.lowercaseString.containsString(searchBar.text!.lowercaseString) && (object.date == strDate) {
                        filteredTableData.append(object)
                    }
                } else {
                    filteredTableData.append(object)
                }
            }
        }
        self.tabelView.reloadData()
    }
    
    func datePickerChanged(datePicker:UIDatePicker) {
        self.filterConcerts()
    }
    
    func loadSampleMeals() {
        let photomap = UIImage(named: "map")!
        
        let latitude1 = 32.629723
        let longitude1 = -117.089889
        let photo1 = UIImage(named: "concert1")!
        let concert1 = Concert(name: "Red Hot Chili Peppers", photo: photo1, date: "04/22/2016", map: photomap, latitude: latitude1, longitude: longitude1)!
        
        let latitude2 = 34.039528
        let longitude2 = -118.246975
        let photo2 = UIImage(named: "concert2")!
        let concert2 = Concert(name: "Sum 41", photo: photo2, date: "04/23/2016", map: photomap, latitude: latitude2, longitude: longitude2)!
        
        let latitude3 = 32.711558
        let longitude3 = -117.157410
        let photo3 = UIImage(named: "concert3")!
        let concert3 = Concert(name: "Panic At The Disco!", photo: photo3, date: "04/24/2016", map: photomap, latitude: latitude3, longitude: longitude3)!
        
        let latitude4 = 32.711558
        let longitude4 = -117.157410
        let photo4 = UIImage(named: "concert3")!
        let concert4 = Concert(name: "Skrillex", photo: photo4, date: "04/24/2016", map: photomap, latitude: latitude4, longitude: longitude4)!
        
        concerts += [concert1, concert2, concert3, concert4]
    }
    
    // MARK: - Table view data source
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.filteredTableData.count
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            let concert = self.filteredTableData[indexPath.row]
            self.filteredTableData.removeAtIndex(indexPath.row)
            if let index = concerts.indexOf(concert) {
                concerts.removeAtIndex(index)
            }
            
            saveConcerts()
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "cell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! TableViewCell
        let concert = self.filteredTableData[indexPath.row]

        cell.button_map.addTarget(self, action: #selector(ViewController.mapAction), forControlEvents: .TouchUpInside)
        cell.button_photo.addTarget(self, action: #selector(ViewController.photoAction), forControlEvents: .TouchUpInside)
        
        cell.name.text = concert.name
        cell.photo.image = concert.photo
        cell.date.text = concert.date
        
        cell.onButtonTapped = {
            self.temp = cell
        }

        return cell
    }
    
    func mapAction(button: UIButton) {
        self.performSegueWithIdentifier("MapView", sender: button)
    }
    
    func photoAction(sender: UITapGestureRecognizer){

            // UIImagePickerController is a view controller that lets a user pick media from their photo library.
            let imagePickerController = UIImagePickerController()
            
            // Only allow photos to be picked, not taken.
            imagePickerController.sourceType = .PhotoLibrary
            
            // Make sure ViewController is notified when the user picks an image.
            imagePickerController.delegate = self
            
            presentViewController(imagePickerController, animated: true, completion: nil)
        
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            temp.photo.image = pickedImage
            let indexPath = tabelView.indexPathForCell(temp)
            concerts[indexPath!.row].photo = pickedImage
            filteredTableData[indexPath!.row].photo = pickedImage
        }
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    // MARK: - SearchBar Delegate
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        self.filterConcerts()
    }
    
    // MARK: - Navigation
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "MapView" {
            let mapDetail = segue.destinationViewController as! MapController
                if let selectedButton = sender as? UIButton {
                let pointInTableView: CGPoint = selectedButton.convertPoint(selectedButton.bounds.origin, toView: self.tabelView)
                let indexPath = tabelView.indexPathForRowAtPoint(pointInTableView)
                let selectedMeal = concerts[indexPath!.row]
                mapDetail._latitude = selectedMeal.latitude!
                mapDetail._longitude = selectedMeal.longitude!
            }
        }
        else if segue.identifier == "AddItem" {
            print("Adding new concert.")
        }
    }
    
    // MARK: NSCoding
    
    func saveConcerts() {
        let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(concerts, toFile: Concert.ArchiveURL.path!)
        if !isSuccessfulSave {
            print("Failed to save concerts...")
        }
    }
    
    func loadConcerts() -> [Concert]? {
        return NSKeyedUnarchiver.unarchiveObjectWithFile(Concert.ArchiveURL.path!) as? [Concert]
    }


}

