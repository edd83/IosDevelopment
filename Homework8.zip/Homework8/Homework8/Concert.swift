//
//  Concert.swift
//  Homework8
//
//  Created by Eddy Lardet on 4/21/16.
//  Copyright © 2016 Eddy Lardet. All rights reserved.
//

import UIKit
import MapKit

class Concert: NSObject, NSCoding {
    // MARK: Properties
    
    var name: String
    var photo: UIImage?
    var date: String
    var map: UIImage?
    var latitude: Double?
    var longitude: Double?
    
    // MARK: Archiving Paths
    
    static let DocumentsDirectory = NSFileManager().URLsForDirectory(.DocumentDirectory, inDomains: .UserDomainMask).first!
    static let ArchiveURL = DocumentsDirectory.URLByAppendingPathComponent("concerts")
    
    // MARK: Types
    
    struct PropertyKey {
        static let nameKey = "name"
        static let photoKey = "photo"
        static let dateKey = "date"
        static let mapKey = "map"
        static let latitudeKey = "latitude"
        static let longitudeKey = "longitude"
    }
    
    // MARK: Initialization
    
    init?(name: String, photo: UIImage?, date: String, map: UIImage?, latitude: Double?, longitude: Double?) {
        
        // Initialize stored properties.
        self.name = name
        self.photo = photo
        self.date = date
        self.map = map
        self.latitude = latitude
        self.longitude = longitude
        
        super.init()
    }
    
    // MARK: NSCoding
    
    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encodeObject(name, forKey: PropertyKey.nameKey)
        aCoder.encodeObject(photo, forKey: PropertyKey.photoKey)
        aCoder.encodeObject(date, forKey: PropertyKey.dateKey)
        aCoder.encodeObject(map, forKey: PropertyKey.mapKey)
        aCoder.encodeObject(latitude, forKey: PropertyKey.latitudeKey)
        aCoder.encodeObject(longitude, forKey: PropertyKey.longitudeKey)
    }
    
    required convenience init?(coder aDecoder: NSCoder) {
        let name = aDecoder.decodeObjectForKey(PropertyKey.nameKey) as! String
        
        // Because photo is an optional property of Concert, use conditional cast.
        let photo = aDecoder.decodeObjectForKey(PropertyKey.photoKey) as? UIImage
        
        let date = aDecoder.decodeObjectForKey(PropertyKey.dateKey) as! String
        
        let map = aDecoder.decodeObjectForKey(PropertyKey.mapKey) as? UIImage
        
        let latitude = aDecoder.decodeObjectForKey(PropertyKey.latitudeKey) as? Double
        
        let longitude = aDecoder.decodeObjectForKey(PropertyKey.longitudeKey) as? Double
        
        // Must call designated initializer.
        self.init(name: name, photo: photo, date: date, map: map, latitude: latitude, longitude: longitude)
    }
    
}