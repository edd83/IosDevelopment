//
//  MapController.swift
//  Homework8
//
//  Created by Eddy Lardet on 4/21/16.
//  Copyright © 2016 Eddy Lardet. All rights reserved.
//

import UIKit
import MapKit

class MapController: UIViewController {
    
    @IBOutlet weak var mapView: MKMapView!
    
    @IBAction func back(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    var _latitude = Double()
    var _longitude = Double()
    var initialLocation: CLLocation!
    
    let regionRadius: CLLocationDistance = 1000.0
    
    func centerMapOnLocation() {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(initialLocation.coordinate,
                                                                  regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: true)
    }
    
    override func viewDidLoad() {
        self.initialLocation = CLLocation(latitude: _latitude, longitude: _longitude)
        centerMapOnLocation()
        let artwork = Artwork(title: "Concert",
                              locationName: "California",
                              discipline: "Concert",
                              coordinate: CLLocationCoordinate2D(latitude: _latitude, longitude: _longitude))
        
        mapView.addAnnotation(artwork)
    }
    
    override func viewWillAppear(animated: Bool) {
        
    }
    
    override func viewDidAppear(animated: Bool) {
        
    }
    
    /*override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        centerMapOnLocation(initialLocation)
        let artwork = Artwork(title: "Red Hot Chili Peppers",
                              locationName: "Chula Vista",
                              discipline: "Concert",
                              coordinate: CLLocationCoordinate2D(latitude: 32.629723, longitude: -117.089889))
        
        mapView.addAnnotation(artwork)
    }*/
}