//
//  TableViewCell.swift
//  Homework8
//
//  Created by Eddy Lardet on 4/20/16.
//  Copyright © 2016 Eddy Lardet. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    @IBOutlet weak var photo: UIImageView!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var date: UILabel!
    
    @IBOutlet weak var map: UIImageView!
    
    @IBOutlet weak var button_photo: UIButton!
    
    @IBOutlet weak var button_map: UIButton!
    
    var onButtonTapped : (() -> Void)? = nil
    
    @IBAction func test(sender: AnyObject) {
        print("lol")
        if let onButtonTapped = self.onButtonTapped {
            onButtonTapped()
        }
    }
    
    @IBAction func test2(sender: AnyObject) {
        print("ili")
        //self.performSegueWithIdentifier("Klikur", sender: self)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
