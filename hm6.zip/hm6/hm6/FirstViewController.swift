//
//  FirstViewController.swift
//  hm6
//
//  Created by Eddy Lardet on 3/29/16.
//  Copyright © 2016 Eddy Lardet. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UIActionSheetDelegate {

    @IBOutlet weak var textfield: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func showActionSheet(sender: AnyObject) {
        let optionMenu = UIAlertController(title: nil, message: "Choose Option", preferredStyle: .ActionSheet)
        
        let deleteAction = UIAlertAction(title: "Delete", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            print("File Deleted")
            let alertController = UIAlertController(title: "ALERT", message:
                "Delete push!", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,
                handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
        })
        
        let saveAction = UIAlertAction(title: "Save", style: .Default, handler: {
            (alert: UIAlertAction!) -> Void in
            print("File Saved")
            let alertController = UIAlertController(title: "ALERT", message:
                "Save push!", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,
                handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .Cancel, handler: {
            (alert: UIAlertAction!) -> Void in
            print("Cancelled")
            let alertController = UIAlertController(title: "ALERT", message:
                "Cancel push!", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default,
                handler: nil))
            
            self.presentViewController(alertController, animated: true, completion: nil)
        })
        
        optionMenu.addAction(deleteAction)
        optionMenu.addAction(saveAction)
        optionMenu.addAction(cancelAction)
        
        self.presentViewController(optionMenu, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepareForSegue(segue:UIStoryboardSegue, sender: AnyObject?) {
        let secondVB: MySecondViewButton = segue.destinationViewController as! MySecondViewButton
        
        secondVB.memorise = textfield.text!
        
    }

}

