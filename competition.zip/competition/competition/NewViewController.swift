//
//  NewViewController.swift
//  competition
//
//  Created by Eddy Lardet on 4/20/16.
//  Copyright © 2016 Eddy Lardet. All rights reserved.
//


import UIKit

class NewViewController: UIViewController
{
    
    
    
    var titleString: String!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.titleLabel.text = self.titleString
        
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
